import turtle
from turtle import Turtle
import pandas

screen = turtle.Screen()
screen.title("U S States Game")

image = "blank_states_img.gif"
screen.addshape(image)
turtle.shape(image)

data = pandas.read_csv("50_states.csv")
all_states = data.state.to_list()
guessed_state = []

while len(guessed_state) < 50:
    ans_state = screen.textinput(title=f"{len(guessed_state)}/50 are correct", prompt="What's another state's name ? ").title()

    if ans_state in all_states:
        guessed_state.append(ans_state)
        t = turtle.Turtle()
        t.hideturtle()
        t.penup()
        state_data = data[data.state == ans_state]
        t.goto(int(state_data.x), int(state_data.y))
        t.write(ans_state)


screen.exitonclick()